package edu.si05.annotations.controlledService;

public class MonServiceImpl implements MonService {

	@Override
	public String convertStr(@NOT_NULL String parmStr) {
		return "***" + parmStr + "***";
	}

	@Override
	public int add(@NUMBER_RANGE(min = 5, max = 20) int nb1, @NUMBER_RANGE(min = 33, max = 42) int nb2) {
		return nb1 + nb2;
	}

}
