package edu.si05.annotations.demo;

import edu.si05.annotations.annotation.A_Initialiser;
import edu.si05.annotations.annotation.Historique;
import edu.si05.annotations.annotation.Info;

//@Historique(
//	{
//		@Info(	auteur= "AISL 2019",  date = "30/09/2019",  version = "1.0"),
//		@Info(	auteur= "AISL 2019",  date = "30/09/2019",  version = "2.0")
//	}
//)
		

//Les annotation seront sotck�es dans le tableau d'Info de l'une annotation Historique
@Info(auteur = "Moi", date = "05/11/2024", version = "1.0")
@Info(auteur = "Moi", date = "06/11/2024", version = "1.1")
public class MaClasse extends MaSuperClasse{  

	@A_Initialiser("ValChamp1")
	protected String champ1;
	
	@A_Initialiser
	private String champ2;
	
	@A_Initialiser("ValChamp3")
	protected String champ3;

	@Override
	public String toString() {
		return "MaClasse [champ0=" + champ0 + ", champ1=" + champ1 + ", champ2=" + champ2 + ", champ3=" + champ3 + "]";
	}

	
	
	
}
