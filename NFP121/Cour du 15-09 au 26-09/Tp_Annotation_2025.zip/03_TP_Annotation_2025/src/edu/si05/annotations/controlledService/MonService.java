package edu.si05.annotations.controlledService;

public interface MonService {

	public String convertStr(String parmStr);

	public int add(int nb1, int nb2);

}
