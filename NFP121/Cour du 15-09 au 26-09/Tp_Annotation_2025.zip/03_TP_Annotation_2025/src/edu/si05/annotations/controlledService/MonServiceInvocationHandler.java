package edu.si05.annotations.controlledService;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class MonServiceInvocationHandler implements InvocationHandler {

	private MonService serviceReel;
	
	public MonServiceInvocationHandler(MonService serviceReel) {
		super();
		this.serviceReel = serviceReel;
	}

	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		if(method.getName().startsWith("conv")) {
			return "44";
		} else {
			return 44;			
		}
	}

}
