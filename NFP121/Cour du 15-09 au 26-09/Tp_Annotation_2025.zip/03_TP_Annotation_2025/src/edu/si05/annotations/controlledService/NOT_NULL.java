package edu.si05.annotations.controlledService;

import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Marqueur pour interdire les valeurs nulles sur les services COntroll�s
 */
@Retention(RUNTIME)
@Target(PARAMETER)
public @interface NOT_NULL {

}
