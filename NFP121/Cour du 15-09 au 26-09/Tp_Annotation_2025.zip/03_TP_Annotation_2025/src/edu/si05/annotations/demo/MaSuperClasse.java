package edu.si05.annotations.demo;

import edu.si05.annotations.annotation.A_Initialiser;

public class MaSuperClasse {

	@A_Initialiser("ValChamp0")
	protected String champ0;
}
