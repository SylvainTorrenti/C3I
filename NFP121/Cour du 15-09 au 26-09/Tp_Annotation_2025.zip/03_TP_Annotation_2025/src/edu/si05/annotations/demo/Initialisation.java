package edu.si05.annotations.demo;

import edu.si05.annotations.Initialiseur;

public class Initialisation {

	public static void main(String[] args) throws IllegalAccessException {

		MaClasse monInstancce = (MaClasse) Initialiseur.initialiser(new MaClasse(), "ZZZ");
		System.out.println(monInstancce);
	}

}
