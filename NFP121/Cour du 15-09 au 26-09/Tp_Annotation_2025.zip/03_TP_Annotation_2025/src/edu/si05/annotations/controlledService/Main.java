package edu.si05.annotations.controlledService;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static class Apple {
		
	}

	public static class Basket<E> {
		E element;
		
		public E getElement() {
			return element;
		}

		public void setElement(E element) {
			this.element = element;
		}
	}
	
	public static boolean isRipe(Apple apple) {
		return true;
	}
 
	
	public static void  insertRipe_A(Apple apple, Basket<Apple> ba)  {
		if(isRipe(apple)) {
			ba.setElement(apple);
		}		
	}
	
	public static void  insertRipe_B(Apple apple, Basket<? extends Apple> ba)  {
		if(isRipe(apple)) {
			// ba.setElement(apple);
		}		
	}

	
	public static void  insertRipe_C(Apple apple, Basket<? super Apple> ba)  {
		if(isRipe(apple)) {
			ba.setElement(apple);
		}		
	}

	public static <A extends Apple> void  insertRipe_D(A apple, Basket<? super Apple> ba)  {
		if(isRipe(apple)) {
			ba.setElement(apple);
		}		
	}
	
	
//	public static <A super Apple> void  insertRipe_E(A apple, Basket<? extends Apple> ba)  {
//		if(isRipe(apple)) {
//			ba.setElement(apple);
//		}		
//	}
	
	public static void main(String[] args) throws Exception {

		MonService monService = ControlledServiceProvider.getControlledService(MonService.class, MonServiceImpl.class);

		System.out.println(monService.convertStr("AA"));
		System.out.println(monService.add(10, 40));

		System.out.println(monService.convertStr(null));
		System.out.println(monService.add(10, 2));
		
		
		
//		// Avec le proxy:
//		monService = (MonService) Proxy.newProxyInstance(MonService.class.getClassLoader(), 
//											new Class[] {MonService.class},
//											new MonServiceInvocationHandler(new MonServiceImpl()));
//
//		System.out.println(monService.convertStr("AA"));
//		System.out.println(monService.add(1, 2));

		
//		List l = new ArrayList();
//		l.add(32);
//		List<String> lstr = l;
//		String str = lstr.get(0);

		Basket<Apple> bo = null;
		if (bo instanceof Basket) {
			
		}
		
		Basket<?> [] tb = new Basket<?>[10]; 
	}

}
