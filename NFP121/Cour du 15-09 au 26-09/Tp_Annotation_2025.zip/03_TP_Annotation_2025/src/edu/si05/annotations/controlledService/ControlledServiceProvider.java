package edu.si05.annotations.controlledService;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.lang.reflect.Proxy;

public class ControlledServiceProvider {

	/**
	 * Retourne une impl�mentation du service de la classe serviceClass dont les param�tres utilis�s lors des appels seront contr�l�s
	 * en se basant sur les annotation @NOT_NULL et @NUMBER_RANGE
	 * @param <T>
	 * @param serviceInterface
	 * @param serviceClass Classe du service poss�dant un constructeur sans param�tre
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getControlledService(Class<T> serviceInterface, Class<? extends T> serviceClass) throws Exception {
		
		// Cr�ation instance du service � contr�ler
		T serviceInstance = serviceClass.newInstance();
		
		// Cr�ation du proxy
		T proxy = (T) Proxy.newProxyInstance(serviceClass.getClassLoader(), 
													new Class[] {serviceInterface},
													new ControlledServiceInvocationHandler(serviceInstance));
		
		return proxy;
	}

	
	/**
	 * M�canisme utilis� par le Proxy pour contr�ler les appels
	 */
	public static class ControlledServiceInvocationHandler implements InvocationHandler {

		private Object serviceReel;
		
		public ControlledServiceInvocationHandler(Object serviceReel) {
			super();
			this.serviceReel = serviceReel;
		}

		@Override
		public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
			// Contr�le des param�tres
			
			int iParameter = 0;

			// R�cup�ration de la m�thode correspondante dans l'impl�mentation :
			Method methodImpl = serviceReel.getClass().getMethod(method.getName(), method.getParameterTypes());

			// D�terminer les param�tres � contr�ler (ceux de la m�thode qui sont annot� avec des contraintes)
			for(Parameter parameter : methodImpl.getParameters()) {
				
				Parameter implParameter = null;
				
				// Recherche annotations sur param�tres
				for(Annotation annotation : parameter.getAnnotations()) {
					
					// Si annotation @NOT_NULL
					if(annotation instanceof NOT_NULL) {
						// V�rification que la valeur de ce param�tre n'est pas null
						if(args[iParameter] == null) {
							throw new IllegalArgumentException("la valeur de " + parameter.getName() + " de la m�thode " + method.getName() + " ne doit pas �tre nulle");
						}
					}

					// Si annotation @NUMBER_RANGE
					if(annotation instanceof NUMBER_RANGE) {
						NUMBER_RANGE contrainteNumber = (NUMBER_RANGE) annotation;
						// V�rification que la valeur de ce param�tre appartient bien � l'intervalle
						Number parmValue = (Number) args[iParameter];
						if(parmValue.doubleValue() < contrainteNumber.min() || parmValue.doubleValue() > contrainteNumber.max()) {
							throw new IllegalArgumentException("la valeur de " + parameter.getName() + " de la m�thode " + method.getName() + " doit �tre entre " + contrainteNumber.min() + " et " + contrainteNumber.max());
						}
					}
					
				}
				
				iParameter++;
				
			}
			
			// Les param�tres ont �t� contr�l�s on peut faire l'appel sur le service r�el
			return method.invoke(serviceReel, args);
		}
		
	}
	
}
