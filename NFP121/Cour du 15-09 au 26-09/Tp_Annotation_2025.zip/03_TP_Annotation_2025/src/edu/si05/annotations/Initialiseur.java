package edu.si05.annotations;

import java.lang.reflect.Field;

import edu.si05.annotations.annotation.A_Initialiser;

/**
 * Classe utilisatire charg�e d'initialiser les propri�t�s des objets 
 * lorsqu'elle sont annot�es avec {@link A_Initialiser} 
 */
public class Initialiseur {

	/**
	 * Initialise tous les champs de l'objet qui sont annot�s avec {@link A_Initialiser} 
	 * 
	 * @param obj
	 * @return
	 * @throws IllegalAccessException 
	 */
	public static Object initialiser(Object obj, String valeurDefaut) throws IllegalAccessException {
		
		// Classe de l'objet � initialiser
		Class<?> objClazz = obj.getClass();
		
		Class<?> curClazz = objClazz;
		while (curClazz != null) {
			// fouille des champs de la classe
			for(Field field : curClazz.getDeclaredFields()) {
				// Si annot�avec A_Initialiser
				A_Initialiser annot = field.getAnnotation(A_Initialiser.class);
				if(annot != null) {
					// Il faut initialiser le champ
					// Avec La valeur pr�sente dans l'annotition ou bien la valeur par d�faut
					String valInit = !"".equals(annot.value()) ? annot.value() : valeurDefaut;
					// affectation de la valeur d'initialisation au champ de l'objet
					boolean isAccessible = field.isAccessible();
					try {
						field.setAccessible(true);
						field.set(obj, valInit);					
					} finally {
						field.setAccessible(isAccessible);					
					}
				}
			}
			curClazz = curClazz.getSuperclass();
		}
		
		return obj;
	}
	
}
